# -*- coding: utf-8 -*-
"""
Created on Sun Oct 22 14:24:11 2023

@author: JorvinZ
"""

import pandas as pd
import matplotlib.pyplot as plt

# Cargamos los datos en un DataFrame (asumiendo que los datos están en un archivo CSV)
data = pd.read_csv('C:/Users/jzapata/Desktop/Python_UdeA/Semana_11_12/UNdata_Export_20231022_214550775.csv')

''' 1) Muertes por año por país, creo el DataFrame aplicando un filtro'''
deaths_by_year = data.groupby(['Country or Area', 'Year'])['Value'].sum().unstack()

#creo la figura para que me devuelva los axis
fig, ax = plt.subplots()
deaths_by_year.plot(kind='bar', stacked=True, ax=ax, linewidth=101, color=['dodgerblue', 'tomato']) #creo el gráfico

#Personalicé el tamaño de los números/ticks y la rotación de los ticks  de los ejes
ax.tick_params(axis='both', labelsize=13)
ax.tick_params(axis='both', labelrotation=0) 
ax.tick_params(axis='both', which='both', length=6, width=1)

#Personalizo los títulos, nombres de los ejes y su tamaño y la leyenda
plt.title('Muertes por año por país')
plt.xlabel('País', fontsize = 12, fontweight='bold')
plt.legend(title='Año')
plt.ylabel('Muertes', fontsize = 12, fontweight='bold')
plt.legend(title='Año')

#con este ciclo personalizo  el grosor de la caja que encierra la gráfica
for spine in ax.spines.values():
    spine.set_linewidth(1)

plt.show()


'''2) Muertes por sexo por país. Acá apliqué el mismo principio que en el ejercicio'''
#anterior, por eso no puse comentyarios
deaths_by_sex = data.groupby(['Country or Area','Year',  'Sex'])['Value'].sum().unstack()
deaths_by_sex.drop(columns= 'Both Sexes', inplace = True)
fig1, ax1 = plt.subplots(figsize=(10, 5))
deaths_by_sex.plot(kind='bar', stacked=True, ax=ax1, linewidth=101)
ax1.tick_params(axis='both', labelsize=13)
ax1.tick_params(axis='both', labelrotation=0) 
ax1.tick_params(axis='both', which='both', length=6, width=1)
plt.title('Muertes por sexo por país en los años 2001 y 2021')
plt.xlabel('País', fontsize = 12, fontweight='bold')
plt.ylabel('Muertes', fontsize = 12, fontweight='bold')
plt.legend(title='Sexo')
for spine in ax1.spines.values():
    spine.set_linewidth(1)

plt.show()


'''3) Muertes por edad por país'''

#Identifiqué que los datos tienen muchas edades, por lo que el gráfico no quedaría de manera óptima 
#utilizando edades individuales como categorías, por lo que dicidí hacer intervalos. No obstante,
#me encuentro que en la base de datos de por si ya hay algunos valores en la columna "Edad" que vienen 
#en intervalos, y con datos extraños por lo que no me dejaría hacer una agrupación correcta.
#Entonces decidí crear una función que tratara con cada uno de estos casos especiales para que finalmente estos
#datos quedaran convertidos en numéricos y poder hacer mi clasificación por intervalos

# Función para convertir valores en 'Age' en valores numéricos
def convert_age_value(age_value):
    age_value = age_value.strip()  # Eliminé espacios alrededor del valor
    age_value = age_value.replace(" ", "")  # Eliminé espacios dentro del valor
    if age_value == 'Total':
        return None  # había un "Total" en esa columna
    if '-' in age_value:
        # Ahora sí si el valor contiene un guion, es un rango de edades, por lo que lo dividí y promedié. Basicamente en el caso de un rango, se toma el promedio, lo que me permite que este valor quede dentro de una de las clasificaciones que hice
        start, end = age_value.split('-')
        if start.isdigit() and end.isdigit():
            return (int(start) + int(end)) / 2
    elif age_value.isdigit():
        # Si el valor es un número, de una lo convierto en un entero
        return int(age_value)
    # Si no es un número, un rango válido o 'Total', devuelve None
    return None

# Aplico la función para crear una nueva columna 'Edad_Numérica'
data['Edad_Numérica'] = data['Age'].apply(convert_age_value)

# Defino los límites de mis intervalos
interval_limits = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 101]

# Creo una nueva columna 'Intervalos' con los intervalos
data['Intervalos'] = pd.cut(data['Edad_Numérica'], bins=interval_limits, right=False, include_lowest=True)

#Agrupo los datos que quiero graficar
deaths_by_age_interval = data.groupby(['Country or Area', 'Year', 'Intervalos'])['Value'].sum().unstack()

#creo el gráfico
fig2, ax2 = plt.subplots(figsize=(12, 6))
deaths_by_age_interval.plot(kind='bar', stacked=True, ax=ax2)
ax2.tick_params(axis='both', labelsize=13)
ax2.tick_params(axis='both', labelrotation=0) 
ax2.tick_params(axis='both', which='both', length=6, width=1)
plt.title('Muertes por edad por país por año')
plt.xlabel('País', fontsize = 12, fontweight='bold')
plt.ylabel('Muertes', fontsize = 12, fontweight='bold')
plt.legend(title='Intervalos de Edad')
for spine in ax2.spines.values():
    spine.set_linewidth(1)

plt.show()
#%%

'''parte 2 del reto'''
''' 1. Estados más afectados por crímenes perpetrados de acuerdo al sexo'''
data2 = pd.read_csv('C:/Users/jzapata/Desktop/Python_UdeA/Semana_11_12/database.csv')

# Filtro los crímenes perpetrados
crimenes_perpetrados = data2[data2['Crime Solved'] == 'Yes']
crimenes_estado_sexo = crimenes_perpetrados.groupby(['State', 'Perpetrator Sex']).size().unstack()

# Ordeno los datos de mayor a menor
crimenes_estado_sexo = crimenes_estado_sexo.sort_values(by=['Male', 'Female'], ascending=False)

# Reordeno las columnas basado en el total de crímenes para que se vea más bonita
crimenes_estado_sexo = crimenes_estado_sexo[crimenes_estado_sexo.sum().sort_values(ascending=False).index]

fig3, ax3 = plt.subplots(figsize=(27, 27))
crimenes_estado_sexo.plot(kind='bar', ax=ax3, width=1)

ax3.tick_params(axis='both', labelsize=13)
ax3.tick_params(axis='x', labelrotation=90)  
ax3.tick_params(axis='both', which='both', length=6, width=1)
ax3.set_title('Crímenes Perpetrados por Estado y Sexo')
ax3.set_xlabel('Estado', fontsize=12, fontweight='bold')
ax3.set_ylabel('Número de Crímenes', fontsize=12, fontweight='bold')

# Agrego etiquetas de datos encima de cada barra
for p in ax3.patches:
    width = p.get_width()
    height = p.get_height()
    x, y = p.get_xy()
    if height > 0:  # Evitar etiquetas en barras vacías
        ax3.annotate(f'{int(height)}', (x + width/2, y + height + 20), ha='center', fontsize=10, rotation=90) 

ax3.legend(title='Sexo', loc='upper right')

# Ajustar el ancho de las líneas del gráfico
for spine in ax3.spines.values():
    spine.set_linewidth(1)
    
plt.show()


'''2. Graficar el número de crímenes de acuerdo al género y la raza'''

# Contar los crímenes por género y raza de la víctima
crimenes_genero_raza = data2.groupby(['Victim Sex', 'Victim Race']).size().unstack()

# Ordeno los datos de mayor a menor
crimenes_genero_raza = crimenes_genero_raza.loc[crimenes_genero_raza.sum(axis=1).sort_values(ascending=False).index]
fig4, ax4 = plt.subplots()

# Grafico el número de crímenes de acuerdo al género y la raza
crimenes_genero_raza.plot(kind='bar', stacked=False, ax=ax4)

ax4.tick_params(axis='both', labelsize=13)
ax4.tick_params(axis='both', labelrotation=0) 
ax4.tick_params(axis='both', which='both', length=6, width=1)
ax4.set_title('Número de Crímenes por Género y Raza de la Víctima')
ax4.set_xlabel('Género de la Víctima', fontsize = 12, fontweight='bold')
ax4.set_ylabel('Número de Crímenes', fontsize = 12, fontweight='bold')

for p in ax4.patches:
    width = p.get_width()
    height = p.get_height()
    x, y = p.get_xy() 
    if height > 0:  # Evitar etiquetas en barras vacías
        ax4.annotate(f'{int(height)}', (x + width/2, y + height + 20), ha='center', fontsize=10, rotation=90) 
        
ax4.legend(title='Raza de la Víctima')
for spine in ax4.spines.values():
    spine.set_linewidth(1)
plt.show()


'''3.'Graficar los crímenes hispanos según el tipo de asesinato.'''

# Filtro los datos para obtener los crímenes perpetrados por víctimas hispanas
crimenes_hispanos = data2[(data2['Victim Ethnicity'] == 'Hispanic') & (data2['Crime Solved'] == 'Yes')]


# Cuento los crímenes hispanos por tipo de asesinato
crimenes_tipo_asesinato = crimenes_hispanos['Crime Type'].value_counts()
fig, ax5 = plt.subplots()

# Grafico los crímenes hispanos según el tipo de asesinato
crimenes_tipo_asesinato.plot(kind='bar', ax = ax5)

ax5.tick_params(axis='both', labelsize=13)
ax5.tick_params(axis='both', labelrotation=0) 
ax5.tick_params(axis='both', which='both', length=6, width=1)
plt.title('Crímenes Hispanos por Tipo de Asesinato')
plt.xlabel('Tipo de Asesinato', fontsize = 12, fontweight='bold')
plt.ylabel('Número de Crímenes', fontsize = 12, fontweight='bold')
for spine in ax5.spines.values():
    spine.set_linewidth(1)
plt.show()


'''4. Graficar las víctimas por tipo raza'''

# Cuento las víctimas por tipo de raza
victimas_raza = data2['Victim Race'].value_counts()

# Grafico las víctimas por tipo de raza
fig, ax6 = plt.subplots(figsize=(12, 6))
victimas_raza.plot(kind='bar')

ax6.tick_params(axis='both', labelsize=13)
ax6.tick_params(axis='both', labelrotation=0) 
ax6.tick_params(axis='both', which='both', length=6, width=1)
plt.title('Víctimas por Tipo de Raza')
plt.xlabel('Raza de la Víctima', fontsize = 12, fontweight='bold')
plt.ylabel('Número de Víctimas', fontsize = 12, fontweight='bold')

for spine in ax6.spines.values():
    spine.set_linewidth(1)
    
plt.show()

'''5. Graficar las víctimas por tipo de asesinato'''

#Contar las víctimas por tipo de asesinato
victimas_tipo_asesinato = data2['Crime Type'].value_counts()

# Graficar las víctimas por tipo de asesinato
fig, ax7 = plt.subplots()
victimas_tipo_asesinato.plot(kind='bar')
ax7.tick_params(axis='both', labelsize=13)
ax7.tick_params(axis='both', labelrotation=0) 
ax7.tick_params(axis='both', which='both', length=6, width=1)
plt.title('Víctimas por Tipo de Asesinato')
plt.xlabel('Tipo de Asesinato', fontsize = 12, fontweight='bold')
plt.ylabel('Número de Víctimas', fontsize = 12, fontweight='bold')
for spine in ax7.spines.values():
    spine.set_linewidth(1)
plt.show()


