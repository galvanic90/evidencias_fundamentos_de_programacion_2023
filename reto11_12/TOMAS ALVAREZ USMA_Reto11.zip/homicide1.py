# -*- coding: utf-8 -*-
"""
@author: tomas alvarez usma
1193130489
"""
import pandas as pd
import matplotlib.pyplot as plt
import os

def save_plot(plot_name):
    answer = input(f"¿Deseas guardar la gráfica {plot_name}? (s/n): ")
    if answer.lower() == 's':
        plt.tight_layout()  # Ajustar la figura antes de guardarla
        plt.savefig(f"{plot_name}.png", dpi=300, bbox_inches='tight')  # Asegurarse de que toda la figura se guarda
        print(f"Gráfica {plot_name} guardada como {plot_name}.png")
    plt.show()

# Obtener la ubicación actual del script
current_directory = os.path.dirname(os.path.realpath(__file__) if '__file__' in locals() else os.getcwd())

# Combinar la ubicación actual con el nombre del archivo CSV
csv_file_path = os.path.join(current_directory, "homicide.csv")

# Cargar los datos desde el archivo CSV
df = pd.read_csv(csv_file_path)

# 1) Graficar los estados más afectados por crímenes perpetrados de acuerdo al sexo
df.groupby(['State', 'Perpetrator Sex']).size().unstack().plot(kind='bar', stacked=True, figsize=(12, 6))
plt.title('Crímenes perpetrados por estado y sexo')
plt.xticks(rotation=45)  # Rotar las etiquetas del eje x
save_plot('crimes_by_state_and_sex')

# 2) Graficar el número de crímenes de acuerdo al género y la raza
df.groupby(['Victim Sex', 'Victim Race']).size().unstack().plot(kind='bar', stacked=True, figsize=(12, 6))
plt.title('Número de crímenes por género y raza')
plt.xticks(rotation=45)
save_plot('crimes_by_gender_and_race')

# 3) Graficar los crímenes hispanos según el tipo de asesinato
df_hispanic = df[df['Victim Ethnicity'] == 'Hispanic']
df_hispanic.groupby('Crime Type').size().plot(kind='bar', figsize=(12, 6))
plt.title('Crímenes hispanos por tipo de asesinato')
plt.xticks(rotation=45)
save_plot('hispanic_crimes_by_type')

# 4) Graficar las víctimas por tipo raza
df['Victim Race'].value_counts().plot(kind='bar', figsize=(12, 6))
plt.title('Víctimas por raza')
plt.xticks(rotation=45)
save_plot('victims_by_race')

# 5) Graficar las víctimas por tipo de asesinato
df['Crime Type'].value_counts().plot(kind='bar', figsize=(12, 6))
plt.title('Víctimas por tipo de asesinato')
plt.xticks(rotation=45)
save_plot('victims_by_crime_type')
