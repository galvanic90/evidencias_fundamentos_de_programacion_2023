# -*- coding: utf-8 -*-
"""


@author: tomas alvarez usma
1193130489
"""
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Establecer el estilo de las gráficas
sns.set_theme()

def save_plot(plot_name):
    answer = input(f"¿Deseas guardar la gráfica {plot_name}? (s/n): ")
    if answer.lower() == 's':
        plt.subplots_adjust(left=0.1, right=0.9, top=0.9, bottom=0.1)  # Ajustar el espaciado manualmente
        plt.savefig(f"{plot_name}.png", dpi=700)
        print(f"Gráfica {plot_name} guardada como {plot_name}.png")
    plt.show()

# Obtener la ubicación actual del script
current_directory = os.path.dirname(os.path.realpath(__file__) if '__file__' in locals() else os.getcwd())

# Combinar la ubicación actual con el nombre del archivo CSV
csv_file_path = os.path.join(current_directory, "UNdata.csv")

# Cargar los datos desde el archivo CSV
data = pd.read_csv(csv_file_path)

# Definir una paleta de colores personalizada para las gráficas
custom_palette = sns.color_palette("viridis", n_colors=len(data["Year"].unique()))

# Agrupar los datos por diferentes categorías y crear gráficas
categories = ["Year", "Sex", "Age"]
titles = ["Número Total de Muertes por Año en Cada País", "Número Total de Muertes por Sexo en Cada País", "Número Total de Muertes por Grupo de Edad en Cada País"]
y_labels = ["Número Total de Muertes", "Número Total de Muertes", "Número Total de Muertes"]

for category, title, y_label in zip(categories, titles, y_labels):
    grouped_data = data.groupby(["Country or Area", category])["Value"].sum()
    plot = grouped_data.unstack().plot(kind="barh", stacked=True, figsize=(25, 20), color=custom_palette, edgecolor="black", grid=True)  # Ajustar el tamaño de la figura aquí

    # Configurar títulos y etiquetas
    plt.title(title, fontsize=20, pad=20)  # Aumentar el espacio entre el título y la gráfica
    plt.ylabel("País", fontsize=15)
    plt.xlabel(y_label, fontsize=15)

    # Añadir una leyenda para explicar los colores de la gráfica
    plt.legend(title=category, title_fontsize='10', fontsize='8', bbox_to_anchor=(1.05, 1), loc='upper left')  # Mover la leyenda aquí

    # Ajustar el layout para asegurar que todo se muestre correctamente
    plt.tight_layout()

    # Personalizar la cuadrícula de números en el eje x
    x_tick_labels = [f'{int(label):,}' for label in plot.get_xticks()]
    plot.set_xticklabels(x_tick_labels)

    # Pregunta al usuario si desea guardar la gráfica
    save_plot(title)

    # Limpiar la figura para el siguiente gráfico
    plt.clf()

