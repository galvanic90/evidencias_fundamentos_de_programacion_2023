"""
Reto Semana 5
 
Presentado por:
    Mariena Rodriguez Oquendo
    CC. 1085331871
"""

import statistics
import numpy as np

# Almacenamiento de información de estudiantes
estudiantes = {}

## Definición para Agregar Estudiantes ##
def agregar_estudiante():
    identificacion = input('Ingrese la identificación del estudiante: ')
    nombre = input('Ingrese el nombre del estudiante: ')
    correo = input('Ingrese el correo del estudiante: ')
    telefono = input('Ingrese el número de teléfono del estudiante: ')
    fecha_nacimiento = input('Ingrese la fecha de nacimiento del estudiante (Día/Mes/Año): ')
    nota1 = float(input('Ingrese la nota 1 del estudiante: '))
    nota2 = float(input('Ingrese la nota 2 del estudiante: '))
    nota3 = float(input('Ingrese la nota 3 del estudiante: '))
    nota4 = float(input('Ingrese la nota 4 del estudiante: '))
    
    estudiantes[identificacion] = {
        'Nombre': nombre,
        'Correo': correo,
        'Teléfono': telefono,
        'Fecha de nacimiento': fecha_nacimiento,
        'Notas': [nota1, nota2, nota3, nota4]  
    }

## Definición para Buscar Estudiante ##
def buscar_estudiante():
    identificacion = input('Ingrese un dato del estudiante que desea buscar: ')
    estudiante = estudiantes.get(identificacion)
    if estudiante:
        print('Información del estudiante:')
        for llave, valor in estudiante.items():
            print(f'{llave}: {valor}')
    else:
        print('El estudiante no se encuentra en la base de datos.')
 
## Definición para Modificar Nota del Estudiante ## 
def modificar_estudiante():
    while True:
        identificacion = input('Ingrese la identificación del estudiante que desea modificar: ')
                 
        estudiante = estudiantes.get(identificacion)
        if estudiante:
            print('Información actual del estudiante:')
            for llave, valor in estudiante.items():
                print(f'{llave}: {valor}')
            
            opcion = input('''
                           Seleccione la nota que desea cambiar:
                               1: Nota 1
                               2: Nota 2
                               3: Nota 3
                               4: Nota 4
                               5: Volver al menú principal
                          ''').strip()
            
            if opcion in ['1', '2', '3', '4']:
                nueva_nota = float(input(f'Nueva nota {opcion}: '))
                estudiante['Notas'][int(opcion) - 1] = nueva_nota
                print(f'La nota {opcion} se cambio exitosamente.')
                break
            elif identificacion == '5':
             print('Esta regresando al menú principal')
             break
            else:
                print('Error, opción no válida.')
                
            
        else:
            print('Estudiante no se encuentra en la base de datos.')

## Definición para Cancelar Materia ##
def cancelar_materia():
    identificacion = input('Ingrese la identificación del estudiante que desea eliminar: ')
    estudiante = estudiantes.get(identificacion)
    if estudiante:
        confirmacion = input('¿Quiere eliminar a este estudiante? (S/N): ').strip().lower()
        if confirmacion == 's':
            del estudiantes[identificacion]
            print('Los datos del estudiante han sido eliminados exitosamente.')
    else:
        print('El estudiante no se encuentra en la base de datos.')

## Definición para Calcular Resultados del Estudiante ##
### Resultados por estudiante ###
def calcular_resultados_estudiante():
    identificacion = input('Ingrese la identificación del estudiante para calcular sus resultados: ')
    estudiante = estudiantes.get(identificacion)
    
    if estudiante:
        notas = estudiante['Notas']
        nota_final = statistics.mean(notas)
        
        # Calcular el percentil del estudiante
        todas_las_notas = [nota for estudiante in estudiantes.values() for nota in estudiante['Notas']]
        
        print('Información del estudiante:')
        for llave, valor in estudiante.items():
            print(f'{llave}: {valor}')
        
        print(f'La nota final del estudiante es de: {nota_final}')
        
        suma_notas_grupo = sum(sum(estudiante['Notas']) for estudiante in estudiantes.values())
        total_notas_grupo = sum(len(estudiante['Notas']) for estudiante in estudiantes.values())

        nota_promedio_grupo = round(suma_notas_grupo / total_notas_grupo, 2)
        
        print(f'La nota promedio del grupo es: {nota_promedio_grupo}')
        
        if nota_final > nota_promedio_grupo: 
            print('El estudiante está por encima del promedio del grupo.') 
        elif nota_final < nota_promedio_grupo:
            print('El estudiante está por debajo del promedio del grupo')
        else: 
            print('El estudiante tiene la misma nota promedio que el grupo.')
                    
        if nota_final >= 2.95:
            print('El estudiante ganó la materia.')
        else:
            print('El estudiante perdió la materia.')        

        estudiante_percentil = np.percentile(todas_las_notas, int((nota_final / 4) / (4 * len(estudiantes)) * 100))
        print(f'El estudiante se encuentra en el percentil {estudiante_percentil}.')

    else:
        print('Estudiante no ha sido encontrado.')

## Definición para Generar Informe del Grupo ##
def generar_informe_grupo():
    if not estudiantes:
        print('No hay estudiantes registrados.')
        return

    notas_finales = [sum(estudiante['Notas']) for estudiante in estudiantes.values()]
    
    suma_notas_grupo = sum(sum(estudiante['Notas']) for estudiante in estudiantes.values())
    total_notas_grupo = sum(len(estudiante['Notas']) for estudiante in estudiantes.values())

    nota_promedio_grupo = round(suma_notas_grupo / total_notas_grupo, 2)
    
    nota_minima = 2.95

    print('Informe de notas del grupo:')
    
    print(f'La nota final de los estudiantes es de: {notas_finales}')
    print(f'La nota promedio del grupo es de: {nota_promedio_grupo}')

    estudiantes_arriba_promedio = 0
    estudiantes_debajo_promedio = 0
    estudiantes_igual_promedio = 0
    estudiantes_ganadores = 0
    estudiantes_perdedores = 0

    for nota in notas_finales:
        
        ## Notas Promedio ##
        if nota > nota_promedio_grupo:
            estudiantes_arriba_promedio += 1
            print(f'Número de estudiantes por encima del promedio: {estudiantes_arriba_promedio}')
        elif nota < nota_promedio_grupo:
            estudiantes_debajo_promedio += 1
            print(f'Número de estudiantes por debajo del promedio: {estudiantes_debajo_promedio}')
        else:
            estudiantes_igual_promedio += 1
            print(f'Número de estudiantes con el mismo promedio del grupo: {estudiantes_igual_promedio}')

        ## Estudiantes que Ganan o Pierden la materia ##
        if nota >= nota_minima:
            estudiantes_ganadores += 1
            print(f'Número de estudiantes ganadores: {estudiantes_ganadores}')
        else:
            estudiantes_perdedores += 1
            print(f'Número de estudiantes perdedores: {estudiantes_perdedores}')

    porcentaje_ganadores = round((estudiantes_ganadores / len(estudiantes)) * 100, 2)
    print(f'Porcentaje de ganadores: {porcentaje_ganadores}%')

    porcentaje_perdedores = round((estudiantes_perdedores / len(estudiantes)) * 100, 2)
    print(f'Porcentaje de perdedores: {porcentaje_perdedores}%')

    percentiles = [int((sum(estudiante['Notas']) / 4) / (4 * len(estudiantes)) * 100) for estudiante in estudiantes.values()]
   
    moda = round(statistics.mode(percentiles), 2)
    mediana = round(statistics.median(percentiles), 2)
    desviacion_estandar = round(statistics.stdev(notas_finales), 2)

    print('Distribución de estudiantes por percentil:')
    for i, valor in enumerate(percentiles, start=1):
        print(f'El estudiante {i} tiene un percentil de: {valor}')

    print(f'La Moda de los percentiles es de: {moda}')
    print(f'La Mediana de los percentiles es de: {mediana}')
    print(f'La Desviación Estándar de las notas finales es de: {desviacion_estandar}')

## Definición de Menú Principal ##
def menu_principal():
    while True:
        print('Menú Principal:')
        print('1: Agregar Estudiante')
        print('2: Buscar Estudiante')
        print('3: Modificar Nota del Estudiante')
        print('4: Cancelación de Materia')
        print('5: Resultados por Estudiante')
        print('6: Informe de Grupo')
        print('7: Salir')
        
        opcion = input('Elija una opción: ').strip()
        
        if opcion == '1':
            agregar_estudiante()
        elif opcion == '2':
            buscar_estudiante()
        elif opcion == '3':
            modificar_estudiante()
        elif opcion == '4':
            cancelar_materia()
        elif opcion == '5':
            calcular_resultados_estudiante()
        elif opcion == '6':
            generar_informe_grupo()
        elif opcion == '7':
            print('Esta saliendo de la aplicación')
            break
        else:
            print('Error, elija una opción válida.')

if __name__ == '__main__':
    menu_principal()