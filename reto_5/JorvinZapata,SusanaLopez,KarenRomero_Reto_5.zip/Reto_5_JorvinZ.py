# -*- coding: utf-8 -*-
"""
Created on Sun Sep 24 14:44:56 2023

@author: JorvinZ
"""
import statistics
import numpy as np

'''El siguiente progrma tiene como objetivo llevar una base de datos
 con las notas de estudiantes durante un curso dado'''

#Creo el diccionario donde voy a guardar los datos de todos los estudiantes.
#Decidí realizarlo con un solo diccionario y los datos de los estudiantes entrarían 
#como valores de las llaves ya establecidas. En este caso empiezo los valores 
#de las llaves como listas vacías para que puedan ser llenadas
estudiantes = {'Identificacion':[],
               'Nombre': [],
               'Correo': [],
               'Telefono':[],
               'Fecha de nacimiento': [],
               'Notas': [] }
#%%
#empiezo a crear las funciones requeridas en el ejercicio para posteriormente
#usarlas en un menu principal.

def Agregar():
    print("Por favor ingrese los siguientes campos")
#en esta función utilizo append() para agregar valores a las llaves ya preestablecidas
#cada vez que el usuario así lo desee.
    estudiantes['Identificacion'].append(int(input('Ingrese su No. de documento: ')))
    estudiantes['Nombre'].append(input('Ingrese su Nombre: '))
    estudiantes['Correo'].append(input('Ingrese su Correo: '))
    estudiantes['Telefono'].append(int(input('Ingrese su Teléfono: ')))
    estudiantes['Fecha de nacimiento'].append(input('Ingrese su Fecha de nacimiento en dd/mm/yyy: '))
    #en cuanto a las notas, como había que ingresar varias, dedicí primero ingresarlas como una lista 
    #luego usé split() para separar los valores y luego utilicé un ciclo para convertir cada nota que estaba como str a float
    notas = input('Ingrese sus notas separadas por comas: '); notas = notas.split(','); notas = [float(nota) for nota in notas]
    estudiantes['Notas'].append(notas)


# esta función buca el nombre del estudiante e inmprime sus datos correspondientes. La estructura usada es sencilla
#como tengo una sola llave con diferentes valores, le digo al usuario que me de el nombre del estudiante
# y luego lo busco en esa llave y tomo su índice, para posteriormente imprimir ese mismo índice en las demás llaves
def Buscar(name):
    if name in estudiantes['Nombre']:
        index = estudiantes['Nombre'].index(name)
        for key, value in estudiantes.items():
            print(f'{key}: {value[index]}')
    else:
        print('Estudiante no encontrado')
        return False
    return True
   
#En esta función utilizó la variable buscar para saber si existe el estudiante, 
#luego solicita al usuario el número de la nota que desea modificar y verifica si es un número válido (1-4) antes de realizar la modificación
def modificar_nota(n1:float):
    name = input('Por favor ingrese el nombre del estudiante al cual desea modificarle la nota: ')
    name = name.capitalize()
    if Buscar(name):
        index_to_modify = int(input('Por favor ingrese el número de la nota que desea modificar (1-4): '))
        index_to_modify -= 1
        
        if 0 <= index_to_modify < 4:
            index = estudiantes['Nombre'].index(name)
            estudiantes['Notas'][index][index_to_modify] = n1
            print('Nota modificada con éxito.')
        else:
            print('Número de nota no válido. Debe ser entre 1 y 4.')
    else:
        print('Estudiante no encontrado.')
 

#Aquí igual volvemos a usar la función Buscar() para saber si existe el estudiante.
#si existe, procedemos a buscar el índice de ese estudiante y a remover ese indice de cada llave
#de esta manera se elimina comopletamente al estudiante del grupo
def cancelar_materia(name):
    if not Buscar(name):
        print('Lo sentimos, el estudiante al que desea cancelarle la materia no existe')
    else: 
        option = int(input('¿Está seguro que desea eliminar al estudiante de la lista? - Escriba 1 si SI o 2 si NO: '))
        if option == 1:
            if name in estudiantes['Nombre']:
                index = estudiantes['Nombre'].index(name)
                datos_eliminados = {
                    'ID': estudiantes['Identificacion'].pop(index),
                    'Nombre': estudiantes['Nombre'].pop(index),
                    'Correo': estudiantes['Correo'].pop(index),
                    'Telefono': estudiantes['Telefono'].pop(index),
                    'Fecha de nacimiento': estudiantes['Fecha de nacimiento'].pop(index),
                    'Nota': estudiantes['Notas'].pop(index)
                }
                return 'Los datos eliminados fueron los siguientes:', datos_eliminados

#Esta función nos da cuenta del informe del estudiante con respecto al grupo
def estudiante_resultados(name):
    if not Buscar(name):
        print('Lo sentimos, el estudiante al que desea cancelarle la materia no existe')
    else:
        index = estudiantes['Nombre'].index(name)
        final_grade = sum(estudiantes['Notas'][index])/4
        notas_aplanadas = [nota for sublist in estudiantes['Notas'] for nota in sublist] #toca aplanar las notas porque tengo una lista de listas
        suma_notas = sum(notas_aplanadas); average_group = suma_notas / len(notas_aplanadas) #sumo notas y luego saco el promedio
        higher_than_average = final_grade > average_group
        pass_or_not = "ganó" if final_grade >= 3.0 else "perdió"

        notas_ordenadas = sorted(estudiantes['Notas'])
        percentil = (notas_ordenadas.index(estudiantes['Notas'][index]) + 1) / len(notas_ordenadas) * 100

        print(f'Nota final de {name}: {final_grade:.2f}')
        print(f'Nota promedio del grupo: {average_group:.2f}')
        if higher_than_average:
            print(f'{name} está por encima de la media.')
        else:
            print(f'{name} está por debajo de la media.')
        print(f'{name} {pass_or_not} el curso.')
        print(f'{name} se encuentra en el percentil {percentil:.2f}%')


#esta función da cuentas de los resultados de todo el grupo
def informe_grupo(estudiantes):
    # nota final del grupo
    final_grades = [sum(notas)/len(notas) for notas in estudiantes['Notas']]
    
    average_group = np.mean(final_grades)  # promedio grupal

    # Número de estudiantes por encima, por debajo e iguales al promedio
    students_above = len([nota for nota in final_grades if nota > average_group])
    students_below = len([nota for nota in final_grades if nota < average_group])
    students_equal = len([nota for nota in final_grades if nota == average_group])

    to_pass = 3.0 #nota minima pa ganar
    
    #los que ganaron y perdieron
    students_pass = len([nota for nota in final_grades if nota >= to_pass])
    students_nopass = len([nota for nota in final_grades if nota < to_pass])
    #ahora en porcentaje
    percentage_pass = (students_pass / len(estudiantes['Nombre'])) * 100
    percentage_nopass = (students_nopass / len(estudiantes['Nombre'])) * 100

    # estad;isticos descriptivos
    mode = statistics.mode(final_grades)
    median = statistics.median(final_grades)
    std_deviation = statistics.stdev(final_grades)

    # Imprimir lo requerido
    print(f'Nota final por estudiante: {final_grades}')
    print(f'Nota promedio del grupo: {average_group}')
    print(f'Número de estudiantes por encima del promedio: {students_above}')
    print(f'Número de estudiantes por debajo del promedio: {students_below}')
    print(f'Número de estudiantes iguales al promedio: {students_equal}')
    print(f'Número de estudiantes ganadores (>= {to_pass}): {students_pass}')
    print(f'Número de estudiantes perdedores (< {to_pass}): {students_nopass}')
    print(f'Porcentaje de ganadores: {percentage_pass:.2f}%')
    print(f'Porcentaje de perdedores: {percentage_nopass:.2f}%')
    print(f'Moda de las notas: {mode:.2f}')
    print(f'Mediana de las notas: {median:.2f}')
    print(f'Desviación estándar de las notas: {std_deviation:.2f}')

#finalmente hago el menu y pongo condicionales y una elección para poner a funcionar cada función
def menu():
    while True:
        print('Escoja una opción: ')
        print('1) Agregar')
        print('2) Buscar')
        print('3) Modificar')
        print('4) Cancelación de materia')
        print('5) Resultados por estudiante')
        print('6) Informe de grupo')
        print('7) Salir')

        choice = int(input('aquí: '))

        if choice == 1:
            Agregar()
            print('')
        elif choice == 2:
            name = input('Ingrese el nombre del estudiante que desea buscar: ')
            Buscar(name)
            print('')
        elif choice == 3:
            n1 = float(input('Ingrese la nueva nota: '))
            modificar_nota(n1)
            print('')
        elif choice == 4:
            name = input('Ingrese el nombre del estudiante al que desea cancelar la materia: ')
            cancelar_materia(name)
            print('')
        elif choice == 5:
            name = input('Ingrese el nombre del estudiante para obtener resultados: ')
            estudiante_resultados(name)
            print('')
        elif choice == 6:
            informe_grupo(estudiantes)
            print('')
        elif choice == 7:
            break
        else:
            print('Opción no válida. Por favor, seleccione una opción válida.')
            
menu()

