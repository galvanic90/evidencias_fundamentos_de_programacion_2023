# -*- coding: utf-8 -*-
"""
Created on Tue Sep 12 18:32:22 2023

@author: erika
"""
import math
alumnos={123:['pepe','pepe@gmail.com', 123456,'1.1.2000',[5.0 , 5.0 , 5.0 , 5.0] ],
         321:['ana','ana@gmail.com', 654321,'1.1.2000', [5.0 , 3.5 , 3.0 , 5.0] ], 
         456:['coco','coco@gmail.com', 654321,'1.1.2000',[5.0 , 5.0 , 4.0 , 5.0] ],}



def agregar():
   n=int(input("cuantos alumnos quiere ingresar? "))
   for x in range(n):
    identificacion= int(input("INGRESE EL NUMERO DE IDENTIFICACION: "))
    nombre=input("INGRESE EL NOMBRE COMPLETO: ")
    correo=input("INGRESE EL CORREO: ")
    telefono=int(input("INGRESE EL NUMERO DE TELEFONO: "))
    fecha_nacimiento=input("INGRESE LA FECHA DE NACIMIENTO SEPARADAS POR PUNTO DD.MM.AA: ")
    nota1=float(input("INGRESE LA PRIMERA NOTA:  "))
    nota2=float(input("INGRESE LA SEGUNDA NOTA:  "))
    nota3=float(input("INGRESE LA TERCERA NOTA:  "))
    nota4=float(input("INGRESE LA CUARTA NOTA: "))
    alumnos[identificacion]=[nombre,correo, telefono,fecha_nacimiento, [nota1 , nota2 , nota3 , nota4]]
   return alumnos
   
    
    
def buscar():
  if len(alumnos)==0:
        print("No hay alumnos ingresados")
        menu()
  num_i=int(input("Ingrese el numero de IDENTIFICACION DEL ALUMNO:"))
  if num_i in alumnos:
    print("LOS DATOS DEL ALUMNO SON",alumnos[num_i])
    return [alumnos[num_i],num_i] 
  else:
    print("NO EXISTE UNA PERSONA CON ESE NUMERO DE IDENTIFICACION ")
    menu()
  
        
def modificar_notas():
   if len(alumnos)==0:
        print("No hay alumnos ingresados")
        menu()
   id_del_alumno=int(input("Ingrese el numero de IDENTIFICACION DEL ALUMNO:"))
   if id_del_alumno in alumnos:
       que_nota_quiere_cambiar=int(input("QUE NOTA DESEA CAMBIAR: "))
       la_nueva_nota=float(input("INGRESE NUEVA NOTA: "))
       alumnos[id_del_alumno][1][que_nota_quiere_cambiar]=la_nueva_nota
   else: 
       print("NO EXISTE UNA PERSONA CON ESE NUMERO_ ")



def cancelar():
    if len(alumnos)==0:
        print("No hay alumnos ingresados")
        menu()
    print ("Aqui puedes cancelar la materia a un alumno")
    id_del_alumno=int(input("Ingrese el numero de IDENTIFICACION DEL ALUMNO QUE QUIERE CANCELAR LA MATERIA: "))
    if id_del_alumno in alumnos:
        del alumnos[id_del_alumno]
    else: 
         print("NO EXISTE UNA PERSONA CON ESE NUMERO_ ")
         
       
def resultados():
    if len(alumnos)==0:
          print("No hay alumnos ingresados")
          menu()
    id_del_alumno =int(input("Ingrese el numero de IDENTIFICACION DEL ALUMNO QUE QUIERE CONOCER SUS RESULTADOS: "))

    if id_del_alumno in alumnos:
        sumaNotas=0
        notaFinal=0
        print (alumnos [id_del_alumno][4])
        for notas in alumnos [id_del_alumno][4]:
            sumaNotas = notas + sumaNotas
        notaFinal =sumaNotas/4
        print("La nota final del alumno", alumnos [id_del_alumno][0]," es ", notaFinal)
    else:
        print("No hay alumnos ingresados")
        menu()
        
def notaPromedio():
    alumno_buscado=buscar()
    notaIndividual = [];
    promedioNota=0;
    notas = 0;
    for nota in alumnos[alumno_buscado[1]][4]:
        notas = nota + notas
        promedioNota = notas/4;
        notaIndividual.append(promedioNota)
        
    if promedioNota >3:
        print ("El estudiante aprobo el curso con nota: ",promedioNota)
    else:
        ("El estudiante NO aprobo el curso con nota: ",promedioNota)

def promedioCurso():
    notaIndividual = []
    for id_del_alumno in alumnos:
        promedioNota=0;
        notas = 0;
        for nota in alumnos [id_del_alumno][4]:
            notas = nota + notas
        promedioNota = notas/4;
        notaIndividual.append(promedioNota)
    media_curso=(sum(notaIndividual)/len(alumnos))   
    print(media_curso)
    return [media_curso,notaIndividual]
   

def media():
    media_total=promedioCurso()
    alumno_buscado=buscar()
    notaIndividual = [];
    promedioNota=0;
    notas = 0;
    
    for nota in alumnos[alumno_buscado[1]][4]:
        notas = nota + notas
        promedioNota = notas/4;
        notaIndividual.append(promedioNota)
        
    if promedioNota > media_total[0]:
        print("El estudiante esta por encima de la media del curso ")
    else:
        print("El estudiante esta por debajo de la media del curso ")
         
# def percentil():
#     notaIndividual = {}
#     for id_del_alumno in alumnos:
#         promedioNota=0;
#         notas = 0;
#         for nota in alumnos [id_del_alumno][4]:
#             notas = nota + notas
#         promedioNota = notas/4;
#         notaIndividual[id_del_alumno]= promedioNota
#     media_curso=(sum(notaIndividual)/len(alumnos)) 
#     ordenMayor = dict(sorted(notaIndividual.items(), key=lambda item:item[1],reverse=True))
#     print(ordenMayor)

def informeGrupo():
    notaIndividual = {}
    prom=promedioCurso()[0]
    for id_del_alumno in alumnos:
        promedioNota=0;
        notas = 0;
        for nota in alumnos [id_del_alumno][4]:
            notas = nota + notas
            promedioNota = notas/4;
            notaIndividual[id_del_alumno]= promedioNota
        if promedioNota > prom:
                print('El alumno',alumnos[id_del_alumno][0], 'esta por encima de la media')
        if promedioNota == prom:
                print('El alumno', alumnos[id_del_alumno][0] ,'esta igual a la media')
        if promedioNota < prom:
                print('El alumno',alumnos[id_del_alumno][0] ,'esta por debajo de la media')
    print('Las notas por alumno son las siguientes: ',notaIndividual)
    print('El promedio del curso es: ', prom=promedioCurso()[0])
    
    
   
    
    
            
            
       
        
    
def menu ():
    
    
        print("""
              
              Bienvenidos a la aplicacion de registro de notas""")
        print("Elija una de las opciones")
        print("1. Agregar alumno")
        print("2. Buscar un alumno")
        print("3. Modificar un alumno")
        print("4. Cancelar materia")
        print("5. Resultados por alumno")
        print("6. Nota promedio alumno")
        print("7. Esta por encima o por debajo de la media")
        print("0. Salir")
        
        opcion=int(input(f'Elija una opcion '))
        if opcion == 1:
            agregar()
        elif opcion == 2:
            buscar()
        elif opcion == 3:
            modificar_notas()
        elif opcion == 4:
            cancelar()
        elif opcion == 5:
             resultados()
        elif opcion == 6:
             notaPromedio()
        elif opcion == 7:
             media()
        elif opcion == 8:
             promedioCurso()
        elif opcion == 9:
             informeGrupo()
        elif opcion == 0:
             menu()
        else:
            print("Ha ingresado una opción erronea")
            False      
while True:
    menu()
   


    
