# -*- coding: utf-8 -*-
"""

@author: tomas alvarez usma
cc: 1193130489
"""
import numpy as np

# Definición de la estructura de datos para almacenar información de estudiantes
estudiantes = {}

# Función para agregar un estudiante
def agregar_estudiante():
    identificacion = input("Identificación del estudiante: ")
    nombre = input("Nombre del estudiante: ")
    correo = input("Correo del estudiante: ")
    telefono = input("Teléfono del estudiante: ")
    fecha_nacimiento = input("Fecha de nacimiento del estudiante: ")
    nota1 = float(input("Nota 1 del estudiante: "))
    nota2 = float(input("Nota 2 del estudiante: "))
    nota3 = float(input("Nota 3 del estudiante: "))
    nota4 = float(input("Nota 4 del estudiante: "))
    
    estudiantes[identificacion] = {
        'Nombre': nombre,
        'Correo': correo,
        'Teléfono': telefono,
        'Fecha de Nacimiento': fecha_nacimiento,
        'Nota 1': nota1,
        'Nota 2': nota2,
        'Nota 3': nota3,
        'Nota 4': nota4
    }

# Función para buscar un estudiante
def buscar_estudiante():
    identificacion = input("Ingrese la identificación del estudiante a buscar: ")
    if identificacion in estudiantes:
        print("Información del estudiante:")
        for clave, valor in estudiantes[identificacion].items():
            print(f"{clave}: {valor}")
    else:
        print("Estudiante no encontrado.")

# Función para modificar las notas de un estudiante
def modificar_notas():
    identificacion = input("Ingrese la identificación del estudiante a modificar: ")
    if identificacion in estudiantes:
        print("Modificar notas del estudiante:")
        estudiantes[identificacion]['Nota 1'] = float(input("Nueva Nota 1: "))
        estudiantes[identificacion]['Nota 2'] = float(input("Nueva Nota 2: "))
        estudiantes[identificacion]['Nota 3'] = float(input("Nueva Nota 3: "))
        estudiantes[identificacion]['Nota 4'] = float(input("Nueva Nota 4: "))
        print("Notas modificadas exitosamente.")
    else:
        print("Estudiante no encontrado.")

# Función para cancelar un estudiante
def cancelar_estudiante():
    identificacion = input("Ingrese la identificación del estudiante a cancelar: ")
    if identificacion in estudiantes:
        confirmacion = input(f"¿Está seguro de cancelar al estudiante {estudiantes[identificacion]['Nombre']}? (S/N): ")
        if confirmacion.lower() == 's':
            del estudiantes[identificacion]
            print("Estudiante cancelado exitosamente.")
    else:
        print("Estudiante no encontrado.")

# Función para calcular los resultados de un estudiante
def calcular_resultados_estudiante(identificacion):
    estudiante = estudiantes[identificacion]
    notas = [estudiante['Nota 1'], estudiante['Nota 2'], estudiante['Nota 3'], estudiante['Nota 4']]
    nota_final = sum(notas) / len(notas)
    
    promedio_grupo = np.mean([np.mean(list(estudiantes[est].values())[4:]) for est in estudiantes])
    
    por_encima_de_la_media = nota_final > promedio_grupo
    ganador = nota_final >= 3.0  # Estableciendo el valor a partir del cual se gana
    
    notas_ordenadas = sorted([np.mean(list(estudiantes[est].values())[4:]) for est in estudiantes])
    percentiles = np.percentile(notas_ordenadas, [25, 50, 75])  # Calcula los percentiles 25, 50 (mediana) y 75
    
    return {
        'Nota Final': nota_final,
        'Promedio del Grupo': promedio_grupo,
        'Por Encima de la Media': por_encima_de_la_media,
        'Ganador': ganador,
        'Percentil 25': percentiles[0],
        'Mediana (Percentil 50)': percentiles[1],
        'Percentil 75': percentiles[2]
    }

# Función para mostrar resultados de un estudiante
def resultados_estudiante():
    identificacion = input("Ingrese la identificación del estudiante para mostrar resultados: ")
    if identificacion in estudiantes:
        resultados = calcular_resultados_estudiante(identificacion)
        print("Resultados del estudiante:")
        for clave, valor in resultados.items():
            print(f"{clave}: {valor}")
    else:
        print("Estudiante no encontrado.")

# Función para calcular estadísticas del grupo
def informe_grupo():
    notas_finales = [calcular_resultados_estudiante(est)['Nota Final'] for est in estudiantes]
    
    promedio_grupo = np.mean(notas_finales)
    
    por_encima_media = len([nota for nota in notas_finales if nota > promedio_grupo])
    por_debajo_media = len([nota for nota in notas_finales if nota < promedio_grupo])
    iguales_media = len([nota for nota in notas_finales if nota == promedio_grupo])
    
    ganadores = len([nota for nota in notas_finales if nota >= 3.0])  # Estableciendo el valor a partir del cual se gana
    perdedores = len(notas_finales) - ganadores
    
    porcentaje_ganadores = (ganadores / len(notas_finales)) * 100
    porcentaje_perdedores = (perdedores / len(notas_finales)) * 100
    
    percentiles = np.percentile(notas_finales, [25, 50, 75])  # Calcula los percentiles 25, 50 (mediana) y 75
    
    moda = max(set(notas_finales), key=notas_finales.count)
    notas_finales.sort()
    mediana = (notas_finales[len(notas_finales) // 2] + notas_finales[(len(notas_finales) - 1) // 2]) / 2
    
    print("Informe del Grupo:")
    print(f"Nota Promedio del Grupo: {promedio_grupo}")
    print(f"Estudiantes por Encima de la Media: {por_encima_media}")
    print(f"Estudiantes por Debajo de la Media: {por_debajo_media}")
    print(f"Estudiantes con Nota Igual a la Media: {iguales_media}")
    print(f"Estudiantes Ganadores: {ganadores}")
    print(f"Estudiantes Perdedores: {perdedores}")
    print(f"Porcentaje de Ganadores: {porcentaje_ganadores}%")
    print(f"Porcentaje de Perdedores: {porcentaje_perdedores}%")
    print(f"Percentil 25: {percentiles[0]}")
    print(f"Mediana (Percentil 50): {percentiles[1]}")
    print(f"Percentil 75: {percentiles[2]}")
    print(f"Moda de las Notas Finales: {moda}")
    print(f"Mediana de las Notas Finales: {mediana}")

# Función principal que muestra el menú y maneja la ejecución del programa
def main():
    while True:
        print("\nMenú:")
        print("1. Agregar Estudiante")
        print("2. Buscar Estudiante")
        print("3. Modificar Notas")
        print("4. Cancelar Estudiante")
        print("5. Resultados por Estudiante")
        print("6. Informe de Grupo")
        print("7. Salir")
        
        opcion = input("Seleccione una opción (1-7): ")
        
        if opcion == '1':
            agregar_estudiante()
        elif opcion == '2':
            buscar_estudiante()
        elif opcion == '3':
            modificar_notas()
        elif opcion == '4':
            cancelar_estudiante()
        elif opcion == '5':
            resultados_estudiante()
        elif opcion == '6':
            informe_grupo()
        elif opcion == '7':
            print("¡Hasta luego!")
            break
        else:
            print("Opción no válida. Intente de nuevo.")

if __name__ == "__main__":
    main()
