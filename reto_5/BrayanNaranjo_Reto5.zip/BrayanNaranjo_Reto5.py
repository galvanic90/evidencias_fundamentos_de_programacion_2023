# -*- coding: utf-8 -*-
"""
Created on Sun Sep 24 19:59:47 2023

@author: Brahi
"""
# Importamos librerias para resolver operaciones

import numpy as np
from scipy import stats

# Usaremos un diccionario para almacenar los datos de los estudiantes

students_data = {}  

def agregar_estudiante():
    identification = input("Identificación: ")
    nombre = input("Nombre: ")
    correo = input("Correo: ")
    telefono = input("Teléfono: ")
    fecha_nacimiento = input("Fecha de nacimiento: ")
    nota1 = float(input("Nota 1: "))
    nota2 = float(input("Nota 2: "))
    nota3 = float(input("Nota 3: "))
    nota4 = float(input("Nota 4: "))

    students_data[identification] = {
        'Nombre': nombre,
        'Correo': correo,
        'Teléfono': telefono,
        'Fecha de nacimiento': fecha_nacimiento,
        'Nota 1': nota1,
        'Nota 2': nota2,
        'Nota 3': nota3,
        'Nota 4': nota4
    }

def buscar_estudiante():
    identification = input("Ingrese la identificación del estudiante: ")
    if identification in students_data:
        print(students_data[identification])
    else:
        print("Estudiante no encontrado.")
        
def modificar_estudiante():
    identification = input("Ingrese la identificación del estudiante a modificar: ")
    if identification in students_data:
        # Obtener el estudiante con la identificación dada
        estudiante = students_data[identification]

        # Solicitar las nuevas notas al usuario
        nueva_nota1 = float(input("Ingrese la nueva Nota 1: "))
        nueva_nota2 = float(input("Ingrese la nueva Nota 2: "))
        nueva_nota3 = float(input("Ingrese la nueva Nota 3: "))
        nueva_nota4 = float(input("Ingrese la nueva Nota 4: "))

        # Actualizar las notas del estudiante
        estudiante["Nota 1"] = nueva_nota1
        estudiante["Nota 2"] = nueva_nota2
        estudiante["Nota 3"] = nueva_nota3
        estudiante["Nota 4"] = nueva_nota4

        print("Notas actualizadas para el estudiante con identificación", identification)
        print("Nuevas notas:", estudiante)
    else:
        print("Estudiante no encontrado.")

def cancelar_materia():
    identification = input("Ingrese la identificación del estudiante a eliminar: ")
    if identification in students_data:
        confirmacion = input("¿Está seguro que desea eliminar al estudiante? (S/N): ")
        if confirmacion.lower() == 's':
            del students_data[identification]
            print("Estudiante eliminado.")
    else:
        print("Estudiante no encontrado.")
        
        
def calcular_nota_promedio_grupo():
    # Inicializar la suma de notas
    suma_notas = 0
    
    # Iterar sobre los estudiantes y sumar sus notas
    for estudiante in students_data.values():
        suma_notas += estudiante['Nota 1'] + estudiante['Nota 2'] + estudiante['Nota 3'] + estudiante['Nota 4']
    
    # Calcular la nota promedio dividiendo la suma por la cantidad de estudiantes
    cantidad_estudiantes = len(students_data)
    nota_promedio = suma_notas / (cantidad_estudiantes * 4)  # 4 notas por estudiante
    
    return nota_promedio


def resultados_por_estudiante():
    identification = input("Ingrese la identificación del estudiante: ")
    if identification in students_data:
        estudiante = students_data[identification]
        
        # Calcular nota final del estudiante
        nota_final = (estudiante['Nota 1'] + estudiante['Nota 2'] + estudiante['Nota 3'] + estudiante['Nota 4']) / 4
        
        # Calcular nota promedio del grupo
        nota_promedio_grupo = calcular_nota_promedio_grupo()
        
        # Comparar con la nota promedio del grupo
        if nota_final > nota_promedio_grupo:
            estado_nota = 'por encima de la media'
        elif nota_final < nota_promedio_grupo:
            estado_nota = 'por debajo de la media'
        else:
            estado_nota = 'igual a la media'
        
        # Determinar si el estudiante ganó o perdió el curso 
        if nota_final >= 3.0:
            estado_curso = 'ganó'
        else:
            estado_curso = 'perdió'
               
        # Mostrar resultados
        print('Nota final del estudiante:', nota_final)
        print('Nota promedio del grupo:', nota_promedio_grupo)
        print('El estudiante está', estado_nota)
        print('El estudiante', estado_curso, 'el curso.')
    else:
        print('Estudiante no encontrado.')
        
def calcular_informe_grupo():
    # Obtener las notas de todos los estudiantes
    notas = [estudiante['Nota 1'] + estudiante['Nota 2'] + estudiante['Nota 3'] + estudiante['Nota 4'] for estudiante in students_data.values()]
    
    # Calcular la nota final por estudiante
    for identification, estudiante in students_data.items():
        estudiante['Nota Final'] = sum(estudiante[f'Nota {i}'] for i in range(1, 5)) / 4
    
    # Calcular la nota promedio
    nota_promedio = calcular_nota_promedio_grupo()
    
    # Calcular el promedio para analizar la posición de los estudiantes
    promedio = sum(notas) / len(notas)
    
    # Calcular el número de estudiantes por encima, por debajo e iguales al promedio
    encima_promedio = sum(1 for nota in notas if nota > promedio)
    debajo_promedio = sum(1 for nota in notas if nota < promedio)
    igual_promedio = sum(1 for nota in notas if nota == promedio)
    
    # Calcular el número de estudiantes ganadores y perdedores
    valor_gana = 3.0 # Establece el valor a partir del cual se considera que un estudiante ha ganado
    
    num_ganadores = sum(1 for nota in notas if nota >= valor_gana)
    num_perdedores = sum(1 for nota in notas if nota < valor_gana)
    
    # Calcular el porcentaje de ganadores y porcentaje de perdedores
    porcentaje_ganadores = (num_ganadores / len(notas)) * 100
    porcentaje_perdedores = (num_perdedores / len(notas)) * 100
    
    # Calcular la distribución de estudiantes por percentil
    percentiles = np.percentile(notas, [25, 50, 75])
    
    # Calcular la moda
    moda = stats.mode(notas)[0][0]
    
    # Calcular la mediana
    mediana = np.median(notas)
    
    # Calcular la desviación estándar
    desviacion_estandar = np.std(notas)
    
    # Imprimir los resultados
    print("Informe de grupo:")
    print("Nota final por estudiante:", {identification: estudiante['Nota Final'] for identification, estudiante in students_data.items()})
    print("Nota promedio:", nota_promedio)
    print("Número de estudiantes por encima del promedio:", encima_promedio)
    print("Número de estudiantes por debajo del promedio:", debajo_promedio)
    print("Número de estudiantes iguales al promedio:", igual_promedio)
    print("Número de estudiantes ganadores:", num_ganadores)
    print("Número de estudiantes perdedores:", num_perdedores)
    print("Porcentaje de ganadores:", porcentaje_ganadores)
    print("Porcentaje de perdedores:", porcentaje_perdedores)
    print("Distribución de estudiantes por percentil:", percentiles)
    print("Moda:", moda)
    print("Mediana:", mediana)
    print("Desviación estándar:", desviacion_estandar)


# Menú de opciones
def menu():
    while True:
        print("\nMenú:")
        print("1. Agregar estudiante")
        print("2. Buscar estudiante")
        print("3. Modificar estudiante")
        print("4. Cancelación de materia")
        print("5. Resultados por estudiante")
        print("6. Informe de grupo")
        print("7. Salir")

        opcion = int(input("Seleccione una opción: "))

        if opcion == 1:
            agregar_estudiante()
        elif opcion == 2:
            buscar_estudiante()
        elif opcion == 3:
            modificar_estudiante()
            pass
        elif opcion == 4:
            cancelar_materia()
            pass
        elif opcion == 5:
            resultados_por_estudiante()
            pass
        elif opcion == 6:
            calcular_informe_grupo()
            pass
        elif opcion == 7:
            break
        else:
            print("Opción no válida. Intente de nuevo.")

# Ejecutar el programa
menu()

