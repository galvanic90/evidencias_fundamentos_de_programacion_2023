#Libretias
import pandas as pd
import numpy as np

#Trea datos
df = pd.read_csv('database.csv')
print(df.head(5))
print(df.info())

#'********************************Punto 1**********************************'

# # Agrupa por ciudad y cuenta el número de agencias en cada ciudad
agencias_por_ciudad = df.groupby('City')['Agency Name'].count().reset_index(name='num_agencias')

# Ordena en orden descendente y toma las cinco primeras filas
top_cinco_ciudades = agencias_por_ciudad.sort_values(by='num_agencias', ascending=False).head(5)
print('''    
      
      ''')
# Imprime el resultado
print(''''********************************Punto 1**********************************
      
      ''')
print(top_cinco_ciudades)


#'********************************Punto 2**********************************'
# Filtrar las filas donde el tipo de agencia es Sheriff
sheriff_agencies = df[df['Agency Type'] == 'Sheriff']

# Mostrar el nombre de las agencias tipo Sheriff
sheriff_names = sheriff_agencies['Agency Name']

print('''    
      
      ''')
print(''''********************************Punto 2**********************************
      
      ''')
print(sheriff_names)


#'********************************Punto 3**********************************'

# Filtrar las filas donde el perpetrador es una mujer
female_perpetrators = df[df['Perpetrator Sex'] == 'Female']

# Contar la cantidad de crímenes por estado
crimes_by_state = female_perpetrators['State'].value_counts()

# Mostrar los estados más afectados
print("Estados más afectados por crímenes perpetrados por mujeres:")

print('''     
      
      ''')
print(''''********************************Punto 3**********************************
      
      ''')
print(crimes_by_state.head())



#'********************************Punto 4**********************************'

# Filtrar las filas donde el perpetrador es un hombre
male_perpetrators = df[df['Perpetrator Sex'] == 'Male']

# Contar la cantidad de crímenes por estado
crimes_by_state = male_perpetrators['State'].value_counts()

# Mostrar los estados más afectados
print("Estados más afectados por crímenes perpetrados por hombres:")

print('''     
      
      ''')
print('''********************************Punto 4**********************************
      
      ''')
print(crimes_by_state.head())


#'********************************Punto 5**********************************'

# Filtrar las filas donde el perpetrador es una mujer de raza Asian/Pacific Islander
female_asian_pacific_perpetrators = df[(df['Perpetrator Sex'] == 'Female') & (df['Perpetrator Race'] == 'Asian/Pacific Islander')]

# Contar el número exacto de crímenes
number_of_crimes = len(female_asian_pacific_perpetrators)


print('''    
      
      ''')
# Mostrar el resultado
print('''********************************Punto 5**********************************
      
      ''')
print("Número exacto de crímenes perpetrados por mujeres de raza Asian/Pacific Islander:", number_of_crimes)


#'********************************Punto 6**********************************'

# Contar la cantidad de crímenes por raza
crimes_by_race = df['Perpetrator Race'].value_counts()

# Contar la cantidad total de personas por raza
total_population_by_race = df['Perpetrator Race'].count()

# Calcular las tasas de criminalidad por raza
crime_rates_by_race = crimes_by_race / total_population_by_race


print('''     
      
      ''')
# Mostrar los resultados
print('''********************************Punto 6**********************************
      
      ''')
print("Tasas de criminalidad por raza:")
print(crime_rates_by_race)


#'********************************Punto 7**********************************'

# Filtrar las filas donde el perpetrador es hispano y el método es estrangulación
hispanic_perpetrators_strangulation = df[(df['Perpetrator Ethnicity'] == 'Hispanic') & (df['Weapon'] == 'Strangulation')]

# Contar el número exacto de casos
number_of_cases = len(hispanic_perpetrators_strangulation)


print('''     
      
      ''')
# Mostrar el resultado
print('''********************************Punto 7**********************************
      
      ''')
print("Número exacto de hispanos que han cometido asesinatos mediante estrangulación:", number_of_cases)



#'********************************Punto 8**********************************'

# Filtrar las filas donde el arma es de tipo Shotgun=escopeta
shotgun_homicides = df[df['Weapon'] == 'Shotgun']

# Contar la cantidad de homicidios por tipo de relación
relationship_homicides = shotgun_homicides['Relationship'].value_counts()


print('''     
      
      ''')
# Mostrar los resultados
print('''********************************Punto 8**********************************
      
      ''')
print("Tipo de relación que comete más homicidios con escopetas:")
print(relationship_homicides.head())


#'********************************Punto 9**********************************'

# Filtrar las filas donde el arma es de tipo Poison=Veneno
poison_homicides = df[df['Weapon'] == 'Poison']

# Contar la cantidad de homicidios por sexo
gender_homicides = poison_homicides['Perpetrator Sex'].value_counts()


print('''     
      
      ''')
# Mostrar los resultados
print('''********************************Punto 9**********************************
      
      ''')
print("Sexo que ha cometido más homicidios con veneno:")
print(gender_homicides.head())


#'********************************Punto 10**********************************'

# Filtrar las filas donde el perpetrador es de raza negra y el FBI está involucrado
black_perpetrators_fbi_involvement = df[(df['Perpetrator Race'] == 'Black') & (df['Record Source'] == 'FBI')]

# Contar la cantidad de asesinos de raza negra atrapados por el FBI
number_of_black_perpetrators_caught_by_fbi = len(black_perpetrators_fbi_involvement)

print('''    
      
      ''')
# Mostrar el resultado
print('''********************************Punto 10**********************************
      
      ''')
print("Número de asesinos de raza negra atrapados por el FBI:", number_of_black_perpetrators_caught_by_fbi)


#'********************************Punto 11**********************************'

# Filtrar las filas donde el tipo de víctima es hispana
hispanic_victims = df[df['Victim Ethnicity'] == 'Hispanic']

# Contar la cantidad de víctimas hispanas por tipo de medio
hispanic_victims_by_weapon = hispanic_victims['Weapon'].value_counts()


print('''     
      
      ''')
# Mostrar los resultados
print('''********************************Punto 11**********************************
      
      ''')
print("Número de víctimas hispanas por tipo de medio:")
print(hispanic_victims_by_weapon)


#'********************************Punto 12**********************************'

# Convertir la columna 'Perpetrator Age' a valores numéricos
df['Perpetrator Age'] = pd.to_numeric(df['Perpetrator Age'], errors='coerce')

# Encontrar el asesino más viejo
oldest_perpetrator = df.loc[df['Perpetrator Age'].idxmax()]


print('''     
      
      ''')
# Mostrar la información del asesino más viejo
print('''********************************Punto 12**********************************
      
      ''')
print("Información del asesino más viejo:")
print(oldest_perpetrator)


#'********************************Punto 13**********************************'

# Encontrar al asesino más joven
youngest_perpetrator = df.loc[df['Perpetrator Age'].idxmin()]


print('''     
      
      ''')
# Mostrar la información del asesino más joven
print('''********************************Punto 13**********************************
      
      ''')
print("Información del asesino más joven:")
print(youngest_perpetrator)


#'********************************Punto 14**********************************'

# Convertir la columna 'Year' a valores numéricos
df['Year'] = pd.to_numeric(df['Year'], errors='coerce')

# Filtrar las filas correspondientes al período 1995-2000
filtered_df = df[(df['Year'] >= 1995) & (df['Year'] <= 2000)]

# Calcular el total de homicidios en ese período
total_homicides = len(filtered_df)


print('''     
      
      ''')
# Mostrar el resultado
print('''********************************Punto 14**********************************
      
      ''')
print("Total de homicidios desde 1995 hasta 2000:", total_homicides)


#'********************************Punto 15**********************************'

# Filtrar las filas correspondientes al período 1995-2000, perpetradas por hombres de raza negra y por sofocación
filtered_data = df[(df['Year'] >= 1995) & (df['Year'] <= 2000) & (df['Perpetrator Sex'] == 'Male') & (df['Perpetrator Race'] == 'Black') & (df['Weapon'] == 'Suffocation')]

# Calcular el total de homicidios en ese período y con esas características
total_homicides = len(filtered_data)


print('''     
      
      ''')
# Mostrar el resultado
print('''********************************Punto 15**********************************
      
      ''')
print("Total de homicidios desde 1995 hasta 2000 perpetrados por hombres de raza negra mediante sofocación:", total_homicides)

#'********************************Punto 16**********************************'

# Filtrar las filas correspondientes a homicidios anteriores a 1980, perpetrados por hombres de raza negra y en el estado de Alaska
filtered_datas = df[(df['Year'] < 1980) & (df['Perpetrator Sex'] == 'Male') & (df['Perpetrator Race'] == 'Black') & (df['State'] == 'Alaska')]


print('''     
      
      ''')
# Mostrar el resultado
print('''********************************Punto 16**********************************
      
      ''')
print("Homicidios anteriores a 1980 perpetrados por hombres de raza negra en el estado de Alaska:")
if len(filtered_datas) > 0:
    print(filtered_datas)
else:
    print('No hay homicidios anteriores a 1980, perpetrados por hombres de raza negra y en el estado de Alaska')


#'********************************Punto 17**********************************'

    # Filtrar las filas correspondientes a homicidios de la policía municipal de la ciudad de Nueva York, perpetrados por relaciones de tipo Ex-Wife y con estrangulación como arma
filtered_datass = df[(df['Agency Type'] == 'Municipal Police') & 
                     (df['Agency Name'] == 'New York') & 
                     (df['Relationship'] == 'Ex-Wife') & 
                     (df['Weapon'] == 'Strangulation')]


print('''     
      
      ''')
# Mostrar el resultado
print('''********************************Punto 17**********************************
      
      ''')
print("Homicidios de la policía municipal de la ciudad de Nueva York perpetrados por relaciones de tipo Ex-Wife con estrangulación como arma:")
print(filtered_datass)

#'********************************Punto 18**********************************'
# Filtrar las filas correspondientes a homicidios desde 1970 hasta 1980 en el estado de Illinois, donde el grupo étnico de la víctima no es hispano, la relación con el asesino fue de amigos y el arma utilizada fue una escopeta
filtered_datasss = df[(df['Year'] >= 1970) & (df['Year'] <= 1980) & 
                     (df['State'] == 'Illinois') & 
                     (df['Victim Ethnicity'] == 'Not Hispanic') & 
                     (df['Relationship'] == 'Friend') & 
                     (df['Weapon'] == 'Shotgun')]

print('''     
      
      ''')
# Mostrar el resultado
print('''********************************Punto 18**********************************
      
      ''')
print("Homicidios desde 1970 hasta 1980 en el estado de Illinois donde el grupo étnico de la víctima no es hispano, la relación con el asesino fue de amigos y el arma utilizada fue una escopeta:")
print(filtered_datasss)


