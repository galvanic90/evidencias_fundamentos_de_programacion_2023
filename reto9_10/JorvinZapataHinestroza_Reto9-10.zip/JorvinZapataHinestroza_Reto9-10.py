# -*- coding: utf-8 -*-
"""
Created on Sun Oct 15 09:33:46 2023

@author: JorvinZ
"""
import pandas as pd


# Cargar los datos en un DataFrame
data = pd.read_csv(r"C:\Users\jzapata\Desktop\Python_UdeA\Semana_9\database.csv")

'''nota: La mayoría de preguntas, para resolverlas, tienen la misma estructura de código, 
por lo tanto, se utilizó esta estructura Ej:  data[(data["Perpetrator Race"] == "Black") & (data["Record Source"] == "FBI")].shape[0]
donde data["Perpetrator Race"] == "Black" me crea una máscara booleana (True and False)
que verifica si el valor en la columna que le di es igual al valor que le di,
la mascara es True donde se cumple la condición, y False donde no se cumple. En algunos 
casos se le agrega otra condición con '&' que hace lo mismo. SI AMBAS SE CUMPLEN, 
el .shape[0] me calcula las dimensiones de DataFrame en las FILAS que queda después de evaluar 
las dos condiciones (mascaras)'''

# 1) 5 primeras ciudadades con más agencias
cities_mostAgencies = data["City"].value_counts().head(5)
print(f"Estas son las 5 ciudades con más número de agencias: \n{cities_mostAgencies}")

# 2) Agencias tipo Sheriff. Los resultados no se muestran en pantalla porque son muchos
#Ya si el usuario gusta podría guardarse en un archivo csv o xlsx
a_sheriff = data[data["Agency Type"] == "Sheriff"]["Agency Name"].unique()
print(f"Agencias de tipo Sheriff:\n{a_sheriff}")

# 3) Estados más afectados por crímenes realizados por mujeres
crimesby_women= data[data["Perpetrator Sex"] == "Female"]["State"].value_counts()
print(f"Estados más afectados por crímenes perpetrados por mujeres:\n{crimesby_women}")

# 4) Estados más afectados por crímenes realizados por hombres
crimesby_men = data[data["Perpetrator Sex"] == "Male"]["State"].value_counts()
print(f"Estados más afectados por crímenes perpetrados por hombres:\n{crimesby_men}")

# 5)  Crímenes hechos por mujeres de raza Asian/Pacific Islander
crimesby_asian_pacific_women = data[(data["Perpetrator Sex"] == "Female") & (data["Perpetrator Race"] == "Asian/Pacific Islander")].shape[0] #la función .shape[0] me hace el conteo del número total de filas que cumplen la condición
print(f"Número de crímenes hechos por mujeres de raza Asian/Pacific Islander: {crimesby_asian_pacific_women}")

# 6) Raza más criminal
most_criminal_race = data["Perpetrator Race"].value_counts().idxmax() #esta última función me permite obtener solo el indice o la etiqueta de la raza que más crimenes cometió
print(f"La raza más criminal es: {most_criminal_race}")

# 7) Hispanos asesinados mediante la estrangulación
strangulation_spanish = data[(data["Perpetrator Race"] == "Hispanic") & (data["Weapon"] == "Strangulation")].shape[0]
print(f"Número de hispanos que han asesinado mediante la estrangulación: {strangulation_spanish}")

# 8) Tipo de relación más peligrosa que comete más homicidios con armas de tipo Shotgun
most_dangerous_relationship = data[data["Weapon"] == "Shotgun"]["Relationship"].value_counts().idxmax()
print(f"La relación más peligrosa que comete más homicidios con armas de tipo Shotgun es: {most_dangerous_relationship}")

# 9) Sexo que más homicidios ha cometido con Veneno
crimes_by_poison = data[data["Weapon"] == "Poison"]["Perpetrator Sex"].value_counts().idxmax()
print(f"El sexo que más homicidios cometetió con Veneno es: {crimes_by_poison}")

# 10) Asesinos de raza negra atrapados por el FBI
back_murderers_captured_ByFBI = data[(data["Perpetrator Race"] == "Black") & (data["Record Source"] == "FBI")].shape[0]
print(f"Número de asesinos de raza negra atrapados por el FBI: {back_murderers_captured_ByFBI}" )

# 11) Víctimas de tipo hispanas que han muerto y el tipo de medio
hispanics_victims = data[data["Victim Ethnicity"] == "Hispanic"]["Weapon"].value_counts()
print(f"Número de víctimas hispanas fallecidas por tipo de medio: \n{hispanics_victims}")

# 12) Asesino más viejo
#tocó converitr los datos de esta columna a numéricos enteros con la función
#pd.to_numeric() porque al parecer había algo que no dejaba ejecutar la línea 71
#por sí sola, además se utilizó errors = 'coerce' que hace parte de la función ya mencionada
#paraponer en NaN aquellos valores no válidos o que no se pueden convertir a numéricos enteros
data["Perpetrator Age"] = pd.to_numeric(data["Perpetrator Age"], errors="coerce")
oldest_murderer = data["Perpetrator Age"].max()
print(f"El asesino más viejo tenía: {oldest_murderer} años")

# 13) Asesino más joven
younger_murderer = data["Perpetrator Age"].min()
print(f"El asesino más joven tenía: {younger_murderer} años")

# 14) Total de homicidios desde 1995 hasta 2000
homicidesrange = data[(data["Year"] >= 1995) & (data["Year"] <= 2000)].shape[0]
print(f"El total de homicidios desde 1995 hasta 2000 es de: {homicidesrange}")

# 15) Homicidios perpetrados por hombres de raza negra por sofocación desde 1995 hasta 2000
suffocation_homicides_byBlackmen = data[(data["Year"] >= 1995) & (data["Year"] <= 2000) & (data["Perpetrator Sex"] == "Male") & (data["Perpetrator Race"] == "Black") & (data["Weapon"] == "Suffocation")].shape[0]
print(f"Homicidios perpetrados por hombres de raza negra por sofocación desde 1995 hasta 2000 es de: {suffocation_homicides_byBlackmen}")

# 16) Homicidios perpetrados por hombres de raza negra en Alaska antes de 1980
homices_byBlackmen_alaskabef1980 = data[(data["State"] == "Alaska") & (data["Perpetrator Sex"] == "Male") & (data["Perpetrator Race"] == "Black") & (data["Year"] < 1980)].shape[0]
print(f"Homicidios perpetrados por hombres de raza negra en Alaska antes de 1980 es de: {homices_byBlackmen_alaskabef1980}")

# 17) Homicidios de la policía municipal de Nueva York por relaciones de tipo Ex-Wife y arma de estrangulación
homicides_bypolice_exwife = data[(data["Agency Name"] == "New York Municipal Police") & (data["Relationship"] == "Ex-Wife") & (data["Weapon"] == "Strangulation")].shape[0]
print(f"No. de homicidios de la policía municipal de Nueva York por relaciones de tipo Ex-Wife y arma de estrangulación: {homicides_bypolice_exwife}")

# 18) Homicidios en Illinois desde 1980 hasta 1970, víctimas no hispanas, relación de amigos y arma tipo escopeta
illinois_homicides_range = data[(data["State"] == "Illinois") & (data["Year"] >= 1970) & (data["Year"] <= 1980) & (data["Victim Ethnicity"] != "Hispanic") & (data["Relationship"] == "Friend") & (data["Weapon"] == "Shotgun")].shape[0]
print(f"Homicidios en Illinois desde 1980 hasta 1970, víctimas no hispanas, relación de amigos y arma tipo escopeta: {illinois_homicides_range}")


