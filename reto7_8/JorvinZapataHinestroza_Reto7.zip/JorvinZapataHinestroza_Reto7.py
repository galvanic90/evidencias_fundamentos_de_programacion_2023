# -*- coding: utf-8 -*-
"""
Created on Sun Oct  8 11:50:41 2023

@author: JorvinZ
"""
import numpy as np

'''NOTA: Por favor correr este código por bloques, dado que por alguna razón, que no pude descifrar,
cuando lo correo todo completo me bota un error en el bloque 4, ya que no puede concatenar
un array de dimensión 30 con otro de una sola dimensión, no obstante esto pasa porque la línea número 34 no se está ejecutando correctamente
cuando corro todo junto. De hecho, al correrlo por bloques esta línea (34) me da un solo valor cuando debería dar 30.
En este caso tiene que darle clic en la linea y darle "run selection or current line" para que pueda funcionar bien'''
'''Punto 1'''
#Creando un arreglo con numeros enteros entre 64 y 1024
arreglo = np.arange(64,1024, dtype = int)
#%%
''' Punto 2'''
#El punto 2 menciona que se haga una matriz cuadrática con los 1024 valores, pero
#teóricamente solo tenemos 960 (1024-64). Así que para poder hacer el ejercicio
#crearé otro arreglo con números aleatorios enteros entre 64 y 1024 de tamaño de 1024 elementos.

arreglo2 = np.random.randint(64,1024, size = 1024)
arreglocua = arreglo2.reshape(32,32)
#%%
'''punto 3''' 

#hice mi propia lista de nombres
names = ['Andrés', 'Carlos', 'Maria', 'Luisa', 'Tatiana', 'Wendy', 'Kelly', 'Yaqueline', 'Jorvin', 'Julio']
nameschoice = np.random.choice(names, size=30)


#Para crear el número de cédulas aleatorio, se utilizó eL formato NUIP (Número Único de Indentificación)
#que empezó a regir a partir del 2003. La estructura es simpe. La función de for _ in range(30)
#me permite crear los números aleatorios (30) de forma independiente y los almacena en una lista
cedulas= [np.random.randint(1040000000, 1099999997) for _ in range(30)]

#y Aquí imprimo los nombres y las cédulas asignadas
for name, cedulas in zip(names, cedulas):
    print(f'Nombre: {name}, ID: {cedulas}')
#%%
'''Punto 4'''
#Para poder concatenar debo convertir ambas variables (nameschoices y cedulas) a una arreglo matricial
# y luego con v.stack, que es uan función que me permite apilar arreglos verticales, concateno las dos variables. 
#El '.T'significa que me transponga el resultado.

nameschoice = np.array(nameschoice)
cedulas = np.array(cedulas)
namesID= np.vstack((nameschoice, cedulas)).T

#%%
'''Punto 5'''
posmax = np.argmax(cedulas)
print(f'Del siguiente listado: \n \n {namesID}, \n \n El número más grande en las cédulas es {posmax} y pertenece al usuario {namesID[posmax]}\n')

