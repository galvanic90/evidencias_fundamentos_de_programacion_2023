"""
Reto Semana 7 y 8
 
Presentado por:
    Mariena Rodriguez Oquendo
    CC. 1085331871
    
"""


# Importación de librería
import numpy as np
import random

# 1. Creación de objeto tipo ndarray, con números enteros entre 64 hasta 1024
n_enteros = np.random.randint(64, 1025, 1024)

print(f'Números enteros: {n_enteros}')

# 2. Redimensión de una matriz bidimensional
red_matriz = n_enteros.reshape(-1, int(np.sqrt(len(n_enteros))))

print('La matriz bidimensional es: ')
print(red_matriz)

# 3. Creación de una columna de datos aleatorios
nombres = ['Andres', 'Maria', 'Manuel', 'Daniel', 'Sarah', 'Cristian', 'Violetta', 'Lucia', 'Jackson', 'Jose']
nombres_aleatorios = random.choices(nombres, k=30)
cedulas_aleatorias = [random.randint(1000000, 9999999) for _ in range(30)]

print('Matriz de nombre en posición aleatoria')
print(nombres_aleatorios)
print('Matriz de cedulas en posición aleatoria')
print(cedulas_aleatorias)

# 4. Concatenar nuevo vector con las observaciones de los nombres y cédulas
n_vector = np.array(list(zip(nombres_aleatorios, cedulas_aleatorias)), dtype='object')

print('Nuevo vector de nombre y cédulas')
print(n_vector)

# 5. Posición del número más grande en las cédulas
max_cedula = np.argmax(n_vector[:, 1].astype(int))

# Mostrar el resultado

print(f'La posición del número más grande en las cédulas es:  {max_cedula}')
