#importamos la libreria numpy
import numpy as np

# Crear un objeto ndarray con números enteros en el rango de 64 a 1024
array_enteros = np.arange(64, 1024, dtype=np.int64)

# Redimensionar a una matriz bidimensional cuadrada
matriz_cuadrada = array_enteros.reshape(int(np.sqrt(len(array_enteros))), -1)

# Imprimir la matriz cuadrada
print(matriz_cuadrada)

# Lista de nombres
nombres = ['Andres', 'Maria', 'Manuel', 'Daniel', 'Sarah', 'Cristian', 'Violetta', 'Lucia', 'Jackson', 'Jose']

# Seleccionar 30 números aleatorios de la matriz
numeros_aleatorios = np.random.choice(matriz_cuadrada.flatten(), size=30)

# Imprimir los números aleatorios seleccionados
print("Números aleatorios seleccionados:")
print(numeros_aleatorios)

#Concatenar
nombres_cedulas = []

# Crear variables usando un ciclo for
for idx, nombre in enumerate(nombres):
    start_idx = idx * 3
    end_idx = (idx + 1) * 3
    nombres_cedulas.append([nombre,int(''.join(map(str,numeros_aleatorios[start_idx:end_idx])))])

# Imprimir los numbres y las cedulas creadas aleatorias
print(nombres_cedulas)

cedulas = []
for idx, cedula in enumerate(nombres_cedulas):
    cedulas.append(cedula[1])

cedula_mayor = max(cedulas)
index_cedula_mayor = cedulas.index(max(cedulas))
print(f'La cédula mas grande es:', cedula_mayor, 'y se encuentra en el index : ',index_cedula_mayor)