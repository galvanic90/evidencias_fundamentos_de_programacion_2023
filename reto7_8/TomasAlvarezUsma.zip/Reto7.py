
#Tomas Alvarez Usma
#1193130489

# Importar la libreri�a necesaria
import numpy as np

# 1. Crear un objeto ndarray con numeros enteros entre 64 y 1024
arreglo = np.arange(64, 1025)

# 2. Redimensionar el arreglo a una matriz cuadrada
matriz = arreglo.reshape((int(np.sqrt(arreglo.size)), -1))
print('Matriz cuadrada:\n', matriz)

# Lista de nombres
nombres = ['Andres','Maria','Manuel','Daniel','Sarah','Cristian','Violetta','Lucia','Jackson','Jose']

# 3. Crear una columna de nombres de 30 registros seleccionados aleatoriamente desde la lista de nombres
nombres_aleatorios = np.random.choice(nombres, 30)
print('Nombres aleatorios:\n', nombres_aleatorios)

# Crear una columna de cedulas de 30 registros generados aleatoriamente
cedulas = np.random.randint(10000000, 100000000, size=30)
print('Cédulas aleatorias:\n', cedulas)

# 4. Concatenar los vectores de nombres y cedulas
concatenado = np.column_stack((nombres_aleatorios, cedulas))
print('Nombres y cedulas:\n', concatenado)

# 5. Encontrar y mostrar la posicion del numero mas grande (cedula) en el vector concatenado
indice_max = np.argmax(cedulas)
print('\El indice del numero de cedula mas grande es:', indice_max)
