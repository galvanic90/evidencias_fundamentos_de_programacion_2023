import folium

# Solicitar al usuario que ingrese la ruta completa donde desea guardar el archivo HTML
ruta_archivo = input("Ingresa la ruta completa donde deseas guardar el archivo HTML del mapa interactivo: ")

# Coordenadas de un punto en Colombia (por ejemplo, Bogotá)
latitud = 4.6097
longitud = -74.0817

# Crear un mapa centrado en las coordenadas
mapa = folium.Map(location=[latitud, longitud], zoom_start=12)

# Agregar un marcador en el punto
folium.Marker([latitud, longitud], tooltip='Bogotá').add_to(mapa)

# Guardar el mapa interactivo en el archivo HTML en la ubicación especificada por el usuario
mapa.save(ruta_archivo)

print(f"Se ha generado un mapa interactivo en '{ruta_archivo}'. Abre el archivo en tu navegador para ver el mapa.")